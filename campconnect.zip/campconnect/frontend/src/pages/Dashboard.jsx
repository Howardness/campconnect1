// src/pages/Dashboard.jsx
import React, { useState } from "react";
import { Link } from "react-router-dom";
import './Dashboard.css';

export default function Dashboard() {
  const [hovered, setHovered] = useState(null);

  return (
    <div className="dashboard-wrapper">
      {/* Header */}
      <div className="dashboard-header">
        <div className="dashboard-logo">
          <img src="/campus-logo.png" alt="Campus Connect Logo" />
        </div>

        <div className="dashboard-nav">
          <Link
            to="/report-issue"
            className="dashboard-button red"
            onMouseEnter={() => setHovered("issue")}
            onMouseLeave={() => setHovered(null)}
          >
            {hovered === "issue" ? "Create" : "Report an Issue"}
          </Link>

          <Link
            to="/schedule-appointment"
            className="dashboard-button green"
            onMouseEnter={() => setHovered("appointment")}
            onMouseLeave={() => setHovered(null)}
          >
            {hovered === "appointment" ? "Create" : "Schedule Appointment"}
          </Link>

          <Link
            to="/view-tickets"
            className="dashboard-button blue"
            onMouseEnter={() => setHovered("tickets")}
            onMouseLeave={() => setHovered(null)}
          >
            {hovered === "tickets" ? "Open" : "View Tickets"}
          </Link>

          <Link
            to="/aboutUs"
            className="dashboard-button info"
            onMouseEnter={() => setHovered("about")}
            onMouseLeave={() => setHovered(null)}
          >
            {hovered === "about" ? "Info" : "About Us"}
          </Link>
        </div>
      </div>

      <h1 className="dashboard-title"></h1>
    </div>
  );
}
