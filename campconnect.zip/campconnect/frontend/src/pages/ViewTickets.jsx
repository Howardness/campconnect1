import React, { useEffect, useState } from "react";

export default function ViewTickets() {
  const [tickets, setTickets] = useState([]);

  useEffect(() => {
    // Simulate fetch
    setTickets([
      { id: 1, type: "Issue", detail: "WiFi not working" },
      { id: 2, type: "Appointment", detail: "Meet advisor on Monday" },
    ]);
  }, []);

  return (
    <div className="max-w-xl mx-auto p-8">
      <h2 className="text-2xl font-bold mb-4">Your Tickets</h2>
      <ul className="space-y-2">
        {tickets.map((ticket) => (
          <li key={ticket.id} className="p-4 border rounded bg-gray-100">
            <strong>{ticket.type}:</strong> {ticket.detail}
          </li>
        ))}
      </ul>
    </div>
  );
}
