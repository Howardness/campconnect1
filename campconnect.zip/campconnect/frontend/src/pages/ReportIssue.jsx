import React, { useState } from "react";
import './ReportIssue.css'; // Make sure the path matches

export default function ReportIssue() {
  const [form, setForm] = useState({
    studentId: "",
    fullName: "",
    category: "",
    details: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Reported Issue:", form);
  };

  return (
    <div className="report-container">
      <form onSubmit={handleSubmit} className="report-form">
        <h2>📣 Report an Issue</h2>

        <input
          name="studentId"
          placeholder="Student ID"
          onChange={handleChange}
          required
        />
        <input
          name="fullName"
          placeholder="Full Name"
          onChange={handleChange}
          required
        />
        <select name="category" onChange={handleChange} required>
          <option value="">📂 Select Category</option>
          <option value="academic">🎓 Academic Issue</option>
          <option value="technical">💻 Technical Issue</option>
          <option value="others">📝 Others</option>
        </select>
        <textarea
          name="details"
          placeholder="📝 Detailed Information"
          onChange={handleChange}
          required
        />

        <button type="submit"> Create Ticket</button>
      </form>
    </div>
  );
}
