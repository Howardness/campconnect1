import React, { useState } from "react";

export default function ScheduleAppointment() {
  const [form, setForm] = useState({
    studentId: "",
    fullName: "",
    category: "",
    priority: "",
    preferredDate: "",
    preferredTime: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Scheduled Appointment:", form);
  };

  return (
    <div className="max-w-xl mx-auto p-8">
      <h2 className="text-2xl font-bold mb-4">Schedule Appointment</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input name="studentId" placeholder="Student ID" className="w-full p-2 border rounded" onChange={handleChange} />
        <input name="fullName" placeholder="Full Name" className="w-full p-2 border rounded" onChange={handleChange} />
        <select name="category" className="w-full p-2 border rounded" onChange={handleChange}>
          <option value="">Select Issue Category</option>
          <option value="academic">Academic Advising</option>
          <option value="registrar">Registrar Service</option>
          <option value="financial">Financial Issue</option>
          <option value="facilities">Facilities Issue</option>
        </select>
        <select name="priority" className="w-full p-2 border rounded" onChange={handleChange}>
          <option value="">Select Priority Level</option>
          <option value="low">Low - Can wait few days</option>
          <option value="medium">Medium - Within 2-3 days</option>
          <option value="high">High - Within 24 hours</option>
        </select>
        <input name="preferredDate" type="date" className="w-full p-2 border rounded" onChange={handleChange} />
        <input name="preferredTime" type="time" className="w-full p-2 border rounded" onChange={handleChange} />
        <button type="submit" className="bg-green-500 text-white p-2 w-full rounded">Schedule</button>
      </form>
    </div>
  );
}