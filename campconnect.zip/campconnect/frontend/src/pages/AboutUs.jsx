import React from 'react';
import { Link } from 'react-router-dom';
import './AboutUs.css';

export default function AboutUs() {
  return (
    <div className="about-wrapper">
      <div className="about-header">
        <img src="/campus-logo.png" alt="Campus Connect Logo" className="about-logo" />
      </div>

      <h2>📘 About <span className="highlight">Campus Connect</span></h2>
      <p><strong>CampusConnect</strong> is a smart and user-friendly...</p>

      <Link to="/dashboard" className="back-button">← Back to Dashboard</Link>
    </div>
  );
}
