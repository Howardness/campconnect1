
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './LoginPage.css';

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    if (username && password) {
      navigate("/dashboard");
    }
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <img
          src="/campus-logo.png"
          alt="Campus Connect Logo"
          className="login-logo"
        />
        <form onSubmit={handleLogin} className="login-form">
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="login-input"
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="login-input"
          />
          <div className="login-links">
            <span className="register-link">Register</span>
            <button type="submit" className="login-button">Log In</button>
          </div>
        </form>
      </div>
    </div>
  );
}
