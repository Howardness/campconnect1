// src/App.jsx
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import Dashboard from "./pages/Dashboard";
import ReportIssue from "./pages/ReportIssue";
import ScheduleAppointment from "./pages/ScheduleAppointment";
import ViewTickets from "./pages/ViewTickets";
import AboutUs from "./pages/AboutUs";
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/report-issue" element={<ReportIssue />} />
        <Route path="/schedule-appointment" element={<ScheduleAppointment />} />
        <Route path="/view-tickets" element={<ViewTickets />} />
        <Route path="/about-us" element={<AboutUs />} />
      </Routes>
    </Router>
  );
}

export default App;
