import React from "react";

export default function TicketCard({ type, detail }) {
  return (
    <div className="p-4 border rounded bg-gray-100">
      <strong>{type}:</strong> {detail}
    </div>
  );
}