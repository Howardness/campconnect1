import axios from "axios";

const BASE_URL = "http://localhost:8080/api";

export const reportIssue = (data) =>
  axios.post(`${BASE_URL}/issues`, data);

export const scheduleAppointment = (data) =>
  axios.post(`${BASE_URL}/appointments`, data);

export const fetchTickets = () =>
  axios.get(`${BASE_URL}/tickets`);